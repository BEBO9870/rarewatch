RareWatch - خطوات التشغيل
1) افتح المجلد بـ Android Studio (Open) واترك Gradle يسوي Sync.
2) نزّل ara.traineddata من:
   https://github.com/tesseract-ocr/tessdata_fast/raw/main/ara.traineddata
   وحطه بالمسار: app/src/main/assets/tessdata/ara.traineddata
3) وصّل الجوال (USB debugging) واضغط Run.
4) من التطبيق: إذن العرض > تشغيل > افتح اللعبة > ▢ حدد المنطقة > ▶
5) عدّل ألوان وحساسية الندرات من: app/src/main/java/com/rarewatch/app/Rules.kt

package com.rarewatch.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

/** طبقة كاملة الشاشة تسحب عليها مستطيل المراقبة */
class RegionPicker(ctx: Context, private val onDone: (RectF) -> Unit) : View(ctx) {
    private var sx = 0f; private var sy = 0f; private var ex = 0f; private var ey = 0f
    private val fill = Paint().apply { color = Color.argb(70, 0, 200, 255) }
    private val line = Paint().apply { color = Color.CYAN; style = Paint.Style.STROKE; strokeWidth = 5f }
    private val txt = Paint().apply { color = Color.WHITE; textSize = 48f; isAntiAlias = true }

    init { setBackgroundColor(Color.argb(110, 0, 0, 0)) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; ex = e.x; ey = e.y }
            MotionEvent.ACTION_MOVE -> { ex = e.x; ey = e.y }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y
                val r = RectF(minOf(sx, ex) / width, minOf(sy, ey) / height,
                              maxOf(sx, ex) / width, maxOf(sy, ey) / height)
                if (r.width() > 0.05f && r.height() > 0.05f) onDone(r) else onDone(RectF())
            }
        }
        invalidate(); return true
    }

    override fun onDraw(c: Canvas) {
        c.drawText("اسحب مستطيل فوق مكان ظهور الاسم والندرة", 40f, 90f, txt)
        if (sx != ex || sy != ey) {
            val r = RectF(minOf(sx, ex), minOf(sy, ey), maxOf(sx, ex), maxOf(sy, ey))
            c.drawRect(r, fill); c.drawRect(r, line)
        }
    }
}

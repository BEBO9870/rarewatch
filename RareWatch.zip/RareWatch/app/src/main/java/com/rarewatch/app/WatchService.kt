package com.rarewatch.app

import android.animation.ObjectAnimator
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.ImageReader
import android.media.RingtoneManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.*

class WatchService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CH = "rw_ch"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var curW = 0; private var curH = 0
    private var scope: CoroutineScope? = null
    private var detector: Detector? = null
    private var panel: View? = null
    private var info: TextView? = null
    private var lastFrame: Bitmap? = null
    private var scans = 0; private var frames = 0
    @Volatile private var running = false
    @Volatile private var lastAlert = 0L
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY

        startFg()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, main)
        }
        wake = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rw:wake").apply { acquire() }

        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope!!.launch {
            val d = Detector(this@WatchService).also { it.init() }
            detector = d
            setInfo(if (d.ocrReady) "جاهز (OCR شغال)" else "جاهز (OCR مو شغال: ملف ara ناقص)")
            loop(d)
        }
        addPanel()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "RareWatch", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, WatchService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setContentTitle("RareWatch شغال")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun setInfo(s: String) { main.post { info?.text = s } }

    // ---------- حلقة الفحص ----------
    private suspend fun loop(d: Detector) {
        while (currentCoroutineContext().isActive) {
            if (running) {
                try { step(d) } catch (e: Exception) { setInfo("خطأ: ${e.javaClass.simpleName} ${e.message}") }
            }
            delay(1000)
        }
    }

    /** يرجّع true إذا تغير حجم الشاشة وانعاد إنشاء العرض */
    private fun ensureDisplay(): Boolean {
        val m = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        val w = m.widthPixels; val h = m.heightPixels
        if (vDisplay != null && w == curW && h == curH) return false
        val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        if (vDisplay == null) {
            vDisplay = projection!!.createVirtualDisplay("rw", w, h, m.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, nr.surface, null, null)
        } else {
            vDisplay!!.resize(w, h, m.densityDpi)
            vDisplay!!.surface = nr.surface
        }
        reader?.close(); reader = nr; curW = w; curH = h
        return true
    }

    private fun step(d: Detector) {
        scans++
        val left = 6000 - (System.currentTimeMillis() - lastAlert)
        if (left > 0) { setInfo("استراحة بعد التنبيه… ${left / 1000}ث"); return }

        if (ensureDisplay()) { lastFrame?.recycle(); lastFrame = null }

        // الشاشة الثابتة ما ترسل إطار جديد، فنحتفظ بآخر إطار ونفحصه
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val p = img.planes[0]
                val rw = p.rowStride / p.pixelStride
                val tmp = Bitmap.createBitmap(rw, img.height, Bitmap.Config.ARGB_8888)
                tmp.copyPixelsFromBuffer(p.buffer)
                val f = if (rw == img.width) tmp else Bitmap.createBitmap(tmp, 0, 0, img.width, img.height)
                if (f !== tmp) tmp.recycle()
                lastFrame?.recycle(); lastFrame = f; frames++
            } finally { img.close() }
        }
        val full = lastFrame
        if (full == null) { setInfo("فحص #$scans: ما وصل إطار من الشاشة بعد"); return }

        val r = Prefs.region(this)
        val x = (r[0] * full.width).toInt().coerceIn(0, full.width - 2)
        val y = (r[1] * full.height).toInt().coerceIn(0, full.height - 2)
        val cw = ((r[2] - r[0]) * full.width).toInt().coerceIn(1, full.width - x)
        val ch = ((r[3] - r[1]) * full.height).toInt().coerceIn(1, full.height - y)
        val region = Bitmap.createBitmap(full, x, y, cw, ch)

        val maxW = 1200
        val bmp = if (region.width > maxW)
            Bitmap.createScaledBitmap(region, maxW, region.height * maxW / region.width, true)
        else region

        val active = Rules.all.filter { Prefs.isEnabled(this, it.id) }
        val hit = d.check(bmp, active, Prefs.ocrConfirm(this))
        if (bmp !== region) bmp.recycle()
        region.recycle()

        setInfo("فحص #$scans (إطارات $frames)\n${d.debug}")
        if (hit != null) {
            lastAlert = System.currentTimeMillis()
            main.post { alert(hit) }
        }
    }

    // ---------- التنبيه ----------
    private fun alert(rule: Rule) {
        try {
            val rt = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            rt.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            rt.play(); main.postDelayed({ rt.stop() }, 3500)
        } catch (_: Exception) {}
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 800), -1))
        } catch (_: Exception) {}
        flash(rule.flashColor)
        toast("لقيت: ${rule.label}")
    }

    private fun flash(color: Int) {
        val v = View(this).apply { setBackgroundColor(color); alpha = 0f }
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        wm.addView(v, lp)
        ObjectAnimator.ofFloat(v, "alpha", 0f, 0.75f, 0f).apply {
            duration = 350; repeatCount = 5
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    try { wm.removeView(v) } catch (_: Exception) {}
                }
            })
            start()
        }
    }

    // ---------- الزر العائم ----------
    private fun tv(t: String) = TextView(this).apply {
        text = t; textSize = 22f; setTextColor(Color.WHITE); setPadding(26, 14, 26, 14)
    }

    private fun addPanel() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val drag = tv("✥"); val play = tv("▶"); val reg = tv("▢"); val close = tv("✕")
        row.addView(drag); row.addView(play); row.addView(reg); row.addView(close)

        val infoView = TextView(this).apply {
            textSize = 11f; setTextColor(Color.LTGRAY); setPadding(24, 0, 24, 14); text = "…"
            maxWidth = 900
        }
        info = infoView

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.argb(200, 20, 20, 20)); cornerRadius = 36f }
            addView(row); addView(infoView)
        }

        val lp = WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }

        var ox = 0; var oy = 0; var tx = 0f; var ty = 0f
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ox = lp.x; oy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - tx).toInt(); lp.y = oy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(col, lp)
                }
            }
            true
        }
        play.setOnClickListener {
            running = !running
            play.text = if (running) "⏹" else "▶"
            if (running) { lastAlert = 0; setInfo("بدأ الفحص…") } else setInfo("متوقف")
        }
        reg.setOnClickListener { pickRegion() }
        close.setOnClickListener { stopSelf() }
        wm.addView(col, lp); panel = col
    }

    private fun pickRegion() {
        val was = running; running = false
        val holder = arrayOfNulls<View>(1)
        val pv = RegionPicker(this) { r ->
            if (r.width() > 0f) {
                Prefs.setRegion(this, r.left, r.top, r.right, r.bottom)
                toast("انحفظت المنطقة")
            }
            holder[0]?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            running = was
        }
        holder[0] = pv
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        wm.addView(pv, lp)
    }

    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    override fun onDestroy() {
        running = false
        scope?.cancel()
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        detector?.release()
        lastFrame?.recycle()
        vDisplay?.release(); reader?.close()
        projection?.stop()
        try { wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}

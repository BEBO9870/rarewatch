package com.rarewatch.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged

class MainActivity : AppCompatActivity() {

    private val portalBoxes = ArrayList<CheckBox>()
    private var status: TextView? = null

    private fun refreshPortals() {
        portalBoxes.forEachIndexed { i, cb ->
            val slot = i + 1
            cb.text = "دوامة $slot: " + (if (Prefs.portal(this, slot) != null) "متعلّمة ✓" else "فاضية")
        }
    }

    private fun refreshStatus() {
        status?.text = if (ScreenWatchService.instance != null) "حالة الخدمة: شغالة ✓"
        else "حالة الخدمة: مو مفعّلة. فعّلها من الخطوة ١"
    }

    override fun onResume() { super.onResume(); refreshPortals(); refreshStatus() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = 40
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size; setPadding(0, 12, 0, 12) }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply { text = t; setOnClickListener { onClick() } }

        root.addView(label("RareWatch", 26f))
        status = label("")
        root.addView(status)

        root.addView(label("اختر الندرات اللي تريد تنبيه عليها (بالكلمة واللون):"))
        Rules.all.forEach { r ->
            root.addView(CheckBox(this).apply {
                text = r.label; isChecked = Prefs.isEnabled(context, r.id)
                setOnCheckedChangeListener { _, v -> Prefs.setEnabled(context, r.id, v) }
            })
        }

        root.addView(label("دوامات متعلّمة (تعلّمها من اللعبة بزر ◎ من الأزرار العائمة):"))
        for (slot in 1..4) {
            val cb = CheckBox(this).apply {
                isChecked = Prefs.isEnabled(context, "portal$slot", true)
                setOnCheckedChangeListener { _, v -> Prefs.setEnabled(context, "portal$slot", v) }
            }
            portalBoxes.add(cb)
            val name = EditText(this).apply {
                hint = "اسم الندرة (مثال: نادر)"
                setText(Prefs.portalName(context, slot))
                doAfterTextChanged { Prefs.setPortalName(context, slot, it?.toString() ?: "") }
            }
            val clear = Button(this).apply {
                text = "مسح الدوامة $slot"
                setOnClickListener { Prefs.clearPortal(context, slot); refreshPortals() }
            }
            root.addView(cb); root.addView(name); root.addView(clear)
        }
        refreshPortals()

        root.addView(CheckBox(this).apply {
            text = "تأكيد بقراءة النص (OCR). شيله إذا ما يقرأ زين، وراح يعتمد على اللون فقط"
            isChecked = Prefs.ocrConfirm(context)
            setOnCheckedChangeListener { _, v -> Prefs.setOcrConfirm(context, v) }
        })

        root.addView(label("الخطوات:\n١) فعّل خدمة RareWatch من إمكانية الوصول\n٢) اضغط إظهار الأزرار\n٣) افتح اللعبة، اضغط ▢ وحدد منطقة المراقبة، ثم ▶"))

        root.addView(btn("١) فتح إعدادات إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("إذا الخدمة رمادية: فتح معلومات التطبيق (اسمح بالإعدادات المقيّدة)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(btn("٢) إظهار الأزرار العائمة") {
            val inst = ScreenWatchService.instance
            if (inst == null) Toast.makeText(this, "فعّل الخدمة أولاً من الخطوة ١", Toast.LENGTH_LONG).show()
            else { inst.showPanel(); moveTaskToBack(true) }
        })
        root.addView(btn("إخفاء الأزرار وإيقاف المراقبة") {
            ScreenWatchService.instance?.hidePanel()
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}

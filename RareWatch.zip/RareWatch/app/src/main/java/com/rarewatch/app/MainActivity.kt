package com.rarewatch.app

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK && res.data != null) {
            val i = Intent(this, WatchService::class.java)
                .putExtra(WatchService.EXTRA_CODE, res.resultCode)
                .putExtra(WatchService.EXTRA_DATA, res.data)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "افتح اللعبة واضغط ▶ من الزر العائم", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = 40
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun label(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size; setPadding(0, 12, 0, 12) }

        root.addView(label("RareWatch", 26f))
        root.addView(label("اختر الندرات اللي تريد تنبيه عليها:"))
        Rules.all.forEach { r ->
            root.addView(CheckBox(this).apply {
                text = r.label; isChecked = Prefs.isEnabled(context, r.id)
                setOnCheckedChangeListener { _, v -> Prefs.setEnabled(context, r.id, v) }
            })
        }
        root.addView(CheckBox(this).apply {
            text = "تأكيد بقراءة النص (OCR). شيله إذا ما يقرأ زين، وراح يعتمد على اللون فقط"
            isChecked = Prefs.ocrConfirm(context)
            setOnCheckedChangeListener { _, v -> Prefs.setOcrConfirm(context, v) }
        })
        root.addView(label("الخطوات:\n١) امنح إذن العرض فوق التطبيقات\n٢) اضغط تشغيل\n٣) افتح اللعبة، اضغط ▢ وحدد منطقة الاسم، ثم ▶"))

        root.addView(Button(this).apply {
            text = "١) إذن العرض فوق التطبيقات"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "٢) تشغيل"
            setOnClickListener { start() }
        })
        root.addView(Button(this).apply {
            text = "إيقاف"
            setOnClickListener {
                startService(Intent(context, WatchService::class.java).setAction(WatchService.ACTION_STOP))
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "امنح إذن العرض فوق التطبيقات أولاً", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }
}

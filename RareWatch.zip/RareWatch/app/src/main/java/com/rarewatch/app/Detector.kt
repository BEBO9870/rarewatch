package com.rarewatch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class Detector(private val ctx: Context) {
    private val tess = TessBaseAPI()
    var ocrReady = false
        private set

    fun init() {
        try {
            val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
            val f = File(dir, "ara.traineddata")
            if (!f.exists()) {
                ctx.assets.open("tessdata/ara.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
            ocrReady = tess.init(ctx.filesDir.absolutePath, "ara")
            if (ocrReady) tess.pageSegMode = TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT
        } catch (e: Exception) {
            ocrReady = false
        }
    }

    fun release() { try { tess.recycle() } catch (_: Exception) {} }

    private fun matches(hsv: FloatArray, r: Rule): Boolean {
        return if (r.hue == null) {
            hsv[1] <= r.minSat && hsv[2] >= r.minVal          // أبيض
        } else {
            val d = Math.abs(hsv[0] - r.hue)
            val dh = minOf(d, 360f - d)
            dh <= r.hueTol && hsv[1] >= r.minSat && hsv[2] >= r.minVal
        }
    }

    private fun norm(s: String) = s
        .replace(Regex("[\\u064B-\\u0652\\u0640\\s]"), "")
        .replace(Regex("[أإآ]"), "ا")
        .replace('ة', 'ه').replace('ى', 'ي')

    /** يرجّع أول قاعدة مطابقة أو null */
    fun check(bmp: Bitmap, rules: List<Rule>): Rule? {
        if (rules.isEmpty()) return null
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val counts = IntArray(rules.size)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            for (i in rules.indices) if (matches(hsv, rules[i])) counts[i]++
        }
        for (i in rules.indices) {
            val r = rules[i]
            if (counts[i] < r.minPixels) continue
            if (r.keyword.isBlank() || !ocrReady) {
                // بدون OCR: نعتمد على اللون فقط (الأبيض لحاله غير موثوق فنتجاهله)
                if (r.hue != null) return r else continue
            }
            // ماسك: البكسلات المطابقة سوداء على خلفية بيضاء، حتى OCR يقرأها أنظف
            val mask = IntArray(w * h)
            for (k in px.indices) {
                Color.colorToHSV(px[k], hsv)
                mask[k] = if (matches(hsv, r)) Color.BLACK else Color.WHITE
            }
            val mb = Bitmap.createBitmap(mask, w, h, Bitmap.Config.ARGB_8888)
            tess.setImage(mb)
            val text = norm(tess.utf8Text ?: "")
            mb.recycle()
            if (text.contains(norm(r.keyword))) return r
        }
        return null
    }
}

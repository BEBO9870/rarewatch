package com.rarewatch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class Detector(private val ctx: Context) {
    private val tess = TessBaseAPI()
    var ocrReady = false
        private set
    @Volatile var debug = ""

    fun init() {
        try {
            val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
            val f = File(dir, "ara.traineddata")
            if (!f.exists()) {
                ctx.assets.open("tessdata/ara.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
            ocrReady = tess.init(ctx.filesDir.absolutePath, "ara")
            if (ocrReady) tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
        } catch (e: Exception) {
            ocrReady = false
        }
    }

    fun release() { try { tess.recycle() } catch (_: Exception) {} }

    private fun matches(hsv: FloatArray, r: Rule): Boolean {
        return if (r.hue == null) {
            hsv[1] <= r.minSat && hsv[2] >= r.minVal          // أبيض
        } else {
            val d = Math.abs(hsv[0] - r.hue)
            val dh = minOf(d, 360f - d)
            dh <= r.hueTol && hsv[1] >= r.minSat && hsv[2] >= r.minVal
        }
    }

    private fun norm(s: String) = s
        .replace(Regex("[\\u064B-\\u0652\\u0640\\s]"), "")
        .replace(Regex("[أإآ]"), "ا")
        .replace('ة', 'ه').replace('ى', 'ي')

    /** يرجّع أول قاعدة مطابقة أو null. يكتب تفاصيل الفحص بالمتغير debug */
    fun check(bmp: Bitmap, rules: List<Rule>): Rule? {
        val sb = StringBuilder()
        if (rules.isEmpty()) { debug = "ما في قواعد مفعّلة"; return null }
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val counts = IntArray(rules.size)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            for (i in rules.indices) if (matches(hsv, rules[i])) counts[i]++
        }
        for (i in rules.indices) sb.append("${rules[i].keyword}: ${counts[i]}px  ")
        sb.append(if (ocrReady) "| OCR جاهز" else "| OCR مو شغال")

        var found: Rule? = null
        for (i in rules.indices) {
            val r = rules[i]
            if (counts[i] < r.minPixels) continue
            if (r.keyword.isBlank() || !ocrReady) {
                if (r.hue != null) { found = r; break } else continue
            }
            // ماسك: البكسلات المطابقة سوداء على أبيض + حدود المنطقة المطابقة
            val mask = IntArray(w * h)
            var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
            for (y in 0 until h) for (x in 0 until w) {
                val k = y * w + x
                Color.colorToHSV(px[k], hsv)
                if (matches(hsv, r)) {
                    mask[k] = Color.BLACK
                    if (x < x0) x0 = x; if (x > x1) x1 = x
                    if (y < y0) y0 = y; if (y > y1) y1 = y
                } else mask[k] = Color.WHITE
            }
            val mb = Bitmap.createBitmap(mask, w, h, Bitmap.Config.ARGB_8888)
            // نقص حول النص ونضبط الحجم حتى يقرأه OCR أحسن، مع إطار أبيض
            val pad = 16
            val cx0 = maxOf(0, x0 - pad); val cy0 = maxOf(0, y0 - pad)
            val cx1 = minOf(w - 1, x1 + pad); val cy1 = minOf(h - 1, y1 + pad)
            var crop = Bitmap.createBitmap(mb, cx0, cy0, cx1 - cx0 + 1, cy1 - cy0 + 1)
            val ch = crop.height
            val target = if (ch > 160) 160f / ch else if (ch < 60) 80f / ch else 1f
            if (target != 1f) {
                crop = Bitmap.createScaledBitmap(crop, maxOf(1, (crop.width * target).toInt()),
                    maxOf(1, (crop.height * target).toInt()), true)
            }
            val framed = Bitmap.createBitmap(crop.width + 40, crop.height + 40, Bitmap.Config.ARGB_8888)
            Canvas(framed).apply { drawColor(Color.WHITE); drawBitmap(crop, 20f, 20f, null) }
            tess.setImage(framed)
            val raw = tess.getUTF8Text() ?: ""
            val text = norm(raw)
            sb.append("  [قرأ: ${raw.trim().take(20)}]")
            mb.recycle(); framed.recycle()
            if (text.contains(norm(r.keyword))) { found = r; break }
        }
        debug = sb.toString()
        return found
    }
}

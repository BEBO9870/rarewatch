package com.rarewatch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class Detector(private val ctx: Context) {
    private val tess = TessBaseAPI()
    var ocrReady = false
        private set
    @Volatile var debug = ""

    fun init() {
        try {
            val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
            val f = File(dir, "ara.traineddata")
            if (!f.exists()) {
                ctx.assets.open("tessdata/ara.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
            ocrReady = tess.init(ctx.filesDir.absolutePath, "ara")
            if (ocrReady) tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE)
        } catch (e: Exception) {
            ocrReady = false
        }
    }

    fun release() { try { tess.recycle() } catch (_: Exception) {} }

    private fun matches(hsv: FloatArray, r: Rule): Boolean {
        return if (r.hue == null) {
            hsv[1] <= r.minSat && hsv[2] >= r.minVal          // أبيض
        } else {
            val d = Math.abs(hsv[0] - r.hue)
            val dh = minOf(d, 360f - d)
            dh <= r.hueTol && hsv[1] >= r.minSat && hsv[2] >= r.minVal
        }
    }

    private fun norm(s: String) = s
        .replace(Regex("[\\u064B-\\u0652\\u0640\\s]"), "")
        .replace(Regex("[أإآ]"), "ا")
        .replace('ة', 'ه').replace('ى', 'ي')

    /** يجمع البكسلات المطابقة بكتل (كل كتلة = كلمة/عنصر). يرجّع [x0,y0,x1,y1,count] */
    private fun clusters(m: BooleanArray, w: Int, h: Int): List<IntArray> {
        val cell = 8
        val gw = (w + cell - 1) / cell; val gh = (h + cell - 1) / cell
        val cnt = IntArray(gw * gh)
        for (y in 0 until h) {
            val row = (y / cell) * gw
            for (x in 0 until w) if (m[y * w + x]) cnt[row + x / cell]++
        }
        val seen = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        val out = ArrayList<IntArray>()
        for (s in cnt.indices) {
            if (cnt[s] == 0 || seen[s]) continue
            var sp = 0; stack[sp++] = s; seen[s] = true
            var cx0 = gw; var cy0 = gh; var cx1 = -1; var cy1 = -1; var total = 0
            while (sp > 0) {
                val c = stack[--sp]; val cy = c / gw; val cx = c % gw
                total += cnt[c]
                if (cx < cx0) cx0 = cx
                if (cx > cx1) cx1 = cx
                if (cy < cy0) cy0 = cy
                if (cy > cy1) cy1 = cy
                for (dy in -2..2) for (dx in -2..2) {
                    val nx = cx + dx; val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val n = ny * gw + nx
                    if (cnt[n] > 0 && !seen[n]) { seen[n] = true; stack[sp++] = n }
                }
            }
            out.add(intArrayOf(cx0 * cell, cy0 * cell,
                minOf(w - 1, (cx1 + 1) * cell - 1), minOf(h - 1, (cy1 + 1) * cell - 1), total))
        }
        return out.filter { it[4] >= 30 }
    }

    /** يرجّع أول قاعدة مطابقة أو null. التفاصيل تنكتب بالمتغير debug */
    fun check(bmp: Bitmap, rules: List<Rule>, ocrConfirm: Boolean): Rule? {
        val sb = StringBuilder()
        if (rules.isEmpty()) { debug = "ما في قواعد مفعّلة"; return null }
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val counts = IntArray(rules.size)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            for (i in rules.indices) if (matches(hsv, rules[i])) counts[i]++
        }
        for (i in rules.indices) sb.append("${rules[i].keyword}: ${counts[i]}px  ")
        val useOcr = ocrReady && ocrConfirm
        sb.append(if (!ocrReady) "| OCR مو شغال" else if (!ocrConfirm) "| لون فقط" else "| OCR")

        var found: Rule? = null
        for (i in rules.indices) {
            val r = rules[i]
            if (counts[i] < r.minPixels) continue
            if (r.keyword.isBlank() || !useOcr) {
                if (r.hue != null) { found = r; break } else continue
            }
            val m = BooleanArray(w * h)
            for (k in px.indices) { Color.colorToHSV(px[k], hsv); m[k] = matches(hsv, r) }
            val cl = clusters(m, w, h).sortedByDescending { it[4] }.take(4)
            sb.append("  كتل=${cl.size}")
            for (c in cl) {
                val pad = 12
                val x0 = maxOf(0, c[0] - pad); val y0 = maxOf(0, c[1] - pad)
                val x1 = minOf(w - 1, c[2] + pad); val y1 = minOf(h - 1, c[3] + pad)
                val cw = x1 - x0 + 1; val ch = y1 - y0 + 1
                val arr = IntArray(cw * ch)
                for (yy in 0 until ch) for (xx in 0 until cw)
                    arr[yy * cw + xx] = if (m[(y0 + yy) * w + x0 + xx]) Color.BLACK else Color.WHITE
                var crop = Bitmap.createBitmap(arr, cw, ch, Bitmap.Config.ARGB_8888)
                val f = 70f / ch
                crop = Bitmap.createScaledBitmap(crop, maxOf(1, (cw * f).toInt()), 70, true)
                val framed = Bitmap.createBitmap(crop.width + 40, crop.height + 40, Bitmap.Config.ARGB_8888)
                Canvas(framed).apply { drawColor(Color.WHITE); drawBitmap(crop, 20f, 20f, null) }
                tess.setImage(framed)
                val raw = tess.getUTF8Text() ?: ""
                crop.recycle(); framed.recycle()
                sb.append(" [قرأ: ${raw.trim().take(14)}]")
                if (norm(raw).contains(norm(r.keyword))) { found = r; break }
            }
            if (found != null) break
        }
        debug = sb.toString()
        return found
    }
}

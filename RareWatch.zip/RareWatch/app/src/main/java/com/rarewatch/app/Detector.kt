package com.rarewatch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class Detector(private val ctx: Context) {
    private val tess = TessBaseAPI()
    var ocrReady = false
        private set
    @Volatile var debug = ""

    fun init() {
        try {
            val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
            val f = File(dir, "ara.traineddata")
            if (!f.exists()) {
                ctx.assets.open("tessdata/ara.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
            ocrReady = tess.init(ctx.filesDir.absolutePath, "ara")
            if (ocrReady) tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE)
        } catch (e: Exception) {
            ocrReady = false
        }
    }

    fun release() { try { tess.recycle() } catch (_: Exception) {} }

    private fun matches(hsv: FloatArray, r: Rule): Boolean {
        return if (r.hue == null) {
            hsv[1] <= r.minSat && hsv[2] >= r.minVal          // أبيض
        } else {
            val d = Math.abs(hsv[0] - r.hue)
            val dh = minOf(d, 360f - d)
            dh <= r.hueTol && hsv[1] >= r.minSat && hsv[2] >= r.minVal
        }
    }

    private fun norm(s: String) = s
        .replace(Regex("[\\u064B-\\u0652\\u0640\\s]"), "")
        .replace(Regex("[أإآ]"), "ا")
        .replace('ة', 'ه').replace('ى', 'ي')

    @Volatile var portalDebug = ""

    /** يفحص ألوان الدوامات المتعلَّمة: يعتمد على أكبر كتلة متجمعة من اللون (مو مجموع البكسلات) */
    fun checkPortals(bmp: Bitmap, portals: List<Portal>, screenArea: Float): Portal? {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val hsvAll = Array(portals.size) { BooleanArray(w * h) }
        val hsv = FloatArray(3)
        for (k in px.indices) {
            Color.colorToHSV(px[k], hsv)
            for (i in portals.indices) {
                val q = portals[i]
                val dd = Math.abs(hsv[0] - q.hue)
                val dh = minOf(dd, 360f - dd)
                if (dh <= q.tol && hsv[1] >= q.minSat && hsv[2] >= q.minVal) hsvAll[i][k] = true
            }
        }
        val sb = StringBuilder()
        var found: Portal? = null
        for (i in portals.indices) {
            val q = portals[i]
            val biggest = clusters(hsvAll[i], w, h).maxOfOrNull { it[4] } ?: 0
            val need = maxOf(40f, 0.35f * q.frac * screenArea).toInt()
            sb.append("${q.label}: ${biggest}/$need  ")
            if (found == null && biggest >= need) found = q
        }
        portalDebug = sb.toString()
        return found
    }

    /** يجمع البكسلات المطابقة بكتل (كل كتلة = كلمة/عنصر). يرجّع [x0,y0,x1,y1,count] */
    private fun clusters(m: BooleanArray, w: Int, h: Int): List<IntArray> {
        val cell = 5
        val gw = (w + cell - 1) / cell; val gh = (h + cell - 1) / cell
        val cnt = IntArray(gw * gh)
        for (y in 0 until h) {
            val row = (y / cell) * gw
            for (x in 0 until w) if (m[y * w + x]) cnt[row + x / cell]++
        }
        val seen = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        val out = ArrayList<IntArray>()
        for (s in cnt.indices) {
            if (cnt[s] == 0 || seen[s]) continue
            var sp = 0; stack[sp++] = s; seen[s] = true
            var cx0 = gw; var cy0 = gh; var cx1 = -1; var cy1 = -1; var total = 0
            while (sp > 0) {
                val c = stack[--sp]; val cy = c / gw; val cx = c % gw
                total += cnt[c]
                if (cx < cx0) cx0 = cx
                if (cx > cx1) cx1 = cx
                if (cy < cy0) cy0 = cy
                if (cy > cy1) cy1 = cy
                for (dy in -1..1) for (dx in -3..3) {
                    val nx = cx + dx; val ny = cy + dy
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val n = ny * gw + nx
                    if (cnt[n] > 0 && !seen[n]) { seen[n] = true; stack[sp++] = n }
                }
            }
            out.add(intArrayOf(cx0 * cell, cy0 * cell,
                minOf(w - 1, (cx1 + 1) * cell - 1), minOf(h - 1, (cy1 + 1) * cell - 1), total))
        }
        return out.filter { it[4] >= 30 }
    }

    private fun lcs(a: String, b: String): Int {
        var best = 0
        val dp = IntArray(b.length + 1)
        for (i in 1..a.length) {
            var prev = 0
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev + 1 else 0
                if (dp[j] > best) best = dp[j]
                prev = tmp
            }
        }
        return best
    }

    /** يقبل القراءة إذا فيها الكلمة، أو جزء كبير منها (OCR أحياناً يقرأ نص الكلمة بس) */
    private fun accept(textN: String, r: Rule): Boolean {
        val k = norm(r.keyword)
        if (textN.isEmpty() || k.isEmpty()) return false
        if (textN.contains(k)) return true
        val need = if (r.hue != null) maxOf(2, k.length - 2) else maxOf(3, k.length - 1)
        return lcs(textN, k) >= need
    }

    /** يرجّع أول قاعدة مطابقة أو null. التفاصيل تنكتب بالمتغير debug */
    fun check(bmp: Bitmap, rules: List<Rule>, ocrConfirm: Boolean): Rule? {
        val sb = StringBuilder()
        if (rules.isEmpty()) { debug = "ما في قواعد مفعّلة"; return null }
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val counts = IntArray(rules.size)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            for (i in rules.indices) if (matches(hsv, rules[i])) counts[i]++
        }
        for (i in rules.indices) sb.append("${rules[i].keyword}: ${counts[i]}px  ")
        val useOcr = ocrReady && ocrConfirm
        sb.append(if (!ocrReady) "| OCR مو شغال" else if (!ocrConfirm) "| لون فقط" else "| OCR")

        var found: Rule? = null
        for (i in rules.indices) {
            val r = rules[i]
            if (counts[i] < r.minPixels) continue
            if (r.keyword.isBlank() || !useOcr) {
                if (r.hue != null) { found = r; break } else continue
            }
            val m = BooleanArray(w * h)
            for (k in px.indices) { Color.colorToHSV(px[k], hsv); m[k] = matches(hsv, r) }
            val isWhite = r.hue == null
            val cl = clusters(m, w, h).filter {
                val bw = it[2] - it[0] + 1; val bh = it[3] - it[1] + 1
                bh in 10..160 && bw >= bh * 0.7 && bw <= bh * 12
            }.sortedByDescending { it[4] }.take(if (isWhite) 10 else 5)
            sb.append("  كتل=${cl.size}")
            for (c in cl) {
                val pad = 12
                val x0 = maxOf(0, c[0] - pad); val y0 = maxOf(0, c[1] - pad)
                val x1 = minOf(w - 1, c[2] + pad); val y1 = minOf(h - 1, c[3] + pad)
                val cw = x1 - x0 + 1; val ch = y1 - y0 + 1
                val arr = IntArray(cw * ch)
                for (yy in 0 until ch) for (xx in 0 until cw)
                    arr[yy * cw + xx] = if (m[(y0 + yy) * w + x0 + xx]) Color.BLACK else Color.WHITE
                val src = Bitmap.createBitmap(arr, cw, ch, Bitmap.Config.ARGB_8888)
                val reads = LinkedHashSet<String>()
                for (hgt in (if (isWhite) intArrayOf(60) else intArrayOf(60, 100))) {
                    val sc = Bitmap.createScaledBitmap(src, maxOf(1, (cw * hgt.toFloat() / ch).toInt()), hgt, true)
                    val framed = Bitmap.createBitmap(sc.width + 40, sc.height + 40, Bitmap.Config.ARGB_8888)
                    Canvas(framed).apply { drawColor(Color.WHITE); drawBitmap(sc, 20f, 20f, null) }
                    for (psm in intArrayOf(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE, TessBaseAPI.PageSegMode.PSM_SINGLE_WORD)) {
                        tess.setPageSegMode(psm)
                        tess.setImage(framed)
                        val raw = (tess.getUTF8Text() ?: "").trim()
                        if (raw.isNotEmpty()) reads.add(raw.take(14))
                        if (accept(norm(raw), r)) { found = r }
                        if (found != null) break
                    }
                    sc.recycle(); framed.recycle()
                    if (found != null) break
                }
                src.recycle()
                sb.append(" [قرأ: ${reads.take(6).joinToString(" | ")}]")
                if (found != null) break
            }
            if (found != null) break
        }
        debug = sb.toString()
        return found
    }
}

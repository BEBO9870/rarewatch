package com.rarewatch.app

import android.accessibilityservice.AccessibilityService
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.*
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.*
import java.util.concurrent.Executors
import kotlin.coroutines.resume

/**
 * خدمة إمكانية وصول: تأخذ لقطة واحدة عند الحاجة (كل ~1 ثانية) بدل البث المستمر،
 * فما تسوي دروب فريم ولا تسخّن الجهاز مثل التقاط الشاشة المستمر.
 */
class ScreenWatchService : AccessibilityService() {
    companion object {
        @Volatile var instance: ScreenWatchService? = null
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var scope: CoroutineScope? = null
    private var detector: Detector? = null
    private var panel: View? = null
    private var info: TextView? = null
    private var playBtn: TextView? = null
    private var scans = 0
    private var slot = 1
    @Volatile private var lastErr = 0
    @Volatile private var running = false
    @Volatile private var lastAlert = 0L
    private var wake: PowerManager.WakeLock? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope!!.launch {
            val d = Detector(this@ScreenWatchService).also { it.init() }
            detector = d
            setInfo(if (d.ocrReady) "جاهز (OCR شغال)" else "جاهز (OCR مو شغال: ملف ara ناقص)")
            loop(d)
        }
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean { cleanup(); return super.onUnbind(intent) }
    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        running = false
        instance = null
        scope?.cancel(); scope = null
        main.post { try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}; panel = null }
        detector?.release(); detector = null
        setWake(false)
    }

    private fun setWake(on: Boolean) {
        try {
            if (on) {
                if (wake == null) wake = (getSystemService(POWER_SERVICE) as PowerManager)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rw:wake")
                if (wake?.isHeld == false) wake?.acquire()
            } else if (wake?.isHeld == true) wake?.release()
        } catch (_: Exception) {}
    }

    private fun setInfo(s: String) { main.post { info?.text = s } }
    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    // ---------- التقاط لقطة عند الطلب ----------
    private suspend fun capture(): Bitmap? = suspendCancellableCoroutine { cont ->
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, exec, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                    var out: Bitmap? = null
                    try {
                        val hb = r.hardwareBuffer
                        val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        out = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle(); hb.close()
                    } catch (_: Exception) {}
                    if (cont.isActive) cont.resume(out)
                }
                override fun onFailure(errorCode: Int) {
                    lastErr = errorCode
                    if (cont.isActive) cont.resume(null)
                }
            })
        } catch (e: Exception) {
            lastErr = -1
            if (cont.isActive) cont.resume(null)
        }
    }

    // ---------- حلقة الفحص ----------
    private suspend fun loop(d: Detector) {
        while (currentCoroutineContext().isActive) {
            if (running) {
                try { scanOnce(d) } catch (e: Exception) { setInfo("خطأ: ${e.javaClass.simpleName} ${e.message}") }
            }
            delay(1100)
        }
    }

    private suspend fun scanOnce(d: Detector) {
        scans++
        val left = 6000 - (System.currentTimeMillis() - lastAlert)
        if (left > 0) { setInfo("استراحة بعد التنبيه… ${left / 1000}ث"); return }

        val full = capture()
        if (full == null) { setInfo("فحص #$scans: ما انلقطت الشاشة (كود $lastErr)"); return }
        try {
            val r = Prefs.region(this)
            val x = (r[0] * full.width).toInt().coerceIn(0, full.width - 2)
            val y = (r[1] * full.height).toInt().coerceIn(0, full.height - 2)
            val cw = ((r[2] - r[0]) * full.width).toInt().coerceIn(1, full.width - x)
            val ch = ((r[3] - r[1]) * full.height).toInt().coerceIn(1, full.height - y)
            val region = Bitmap.createBitmap(full, x, y, cw, ch)

            val maxW = 1200
            val bmp = if (region.width > maxW)
                Bitmap.createScaledBitmap(region, maxW, region.height * maxW / region.width, true)
            else region
            val sc = bmp.width.toFloat() / cw
            val screenArea = full.width.toFloat() * full.height * sc * sc

            val sb = StringBuilder("فحص #$scans")
            var hitLabel: String? = null
            var hitColor = 0xFFFFC107.toInt()

            // 1) الدوامات المتعلَّمة: سريعة وبدون OCR
            val portals = (1..4).filter { Prefs.isEnabled(this, "portal$it", true) }
                .mapNotNull { Prefs.portal(this, it) }
            if (portals.isNotEmpty()) {
                val hp = d.checkPortals(bmp, portals, screenArea)
                sb.append("\n").append(d.portalDebug)
                if (hp != null) hitLabel = hp.label
            }

            // 2) قواعد الكلمة + اللون
            val active = Rules.all.filter { Prefs.isEnabled(this, it.id) }
            if (hitLabel == null && active.isNotEmpty()) {
                val hr = d.check(bmp, active, Prefs.ocrConfirm(this))
                sb.append("\n").append(d.debug)
                if (hr != null) { hitLabel = hr.label; hitColor = hr.flashColor }
            }

            if (bmp !== region) bmp.recycle()
            region.recycle()

            setInfo(sb.toString())
            if (hitLabel != null) {
                lastAlert = System.currentTimeMillis()
                val lbl: String = hitLabel
                val col = hitColor
                main.post { alert(lbl, col) }
            }
        } finally { full.recycle() }
    }

    // ---------- تعليم لون دوامة ----------
    private suspend fun learnFrom(r: RectF, slotNow: Int) {
        val full = capture()
        val msg = if (full == null) "ما قدرت آخذ صورة من الشاشة (كود $lastErr)"
        else try { learnCompute(full, r, slotNow) } catch (e: Exception) { "فشل التعليم: ${e.message}" }
        full?.recycle()
        toast(msg); setInfo(msg)
    }

    private fun learnCompute(f: Bitmap, r: RectF, slotNow: Int): String {
        val x = (r.left * f.width).toInt().coerceIn(0, f.width - 3)
        val y = (r.top * f.height).toInt().coerceIn(0, f.height - 3)
        val w = ((r.right - r.left) * f.width).toInt().coerceIn(2, f.width - x)
        val h = ((r.bottom - r.top) * f.height).toInt().coerceIn(2, f.height - y)
        var sample = Bitmap.createBitmap(f, x, y, w, h)
        val big = maxOf(w, h)
        if (big > 160) {
            val k = 160f / big
            sample = Bitmap.createScaledBitmap(sample, maxOf(1, (w * k).toInt()), maxOf(1, (h * k).toInt()), true)
        }
        val sw = sample.width; val sh = sample.height
        val px = IntArray(sw * sh)
        sample.getPixels(px, 0, sw, 0, 0, sw, sh)
        val hist = IntArray(36); val sumS = FloatArray(36); val sumV = FloatArray(36)
        val hsv = FloatArray(3)
        var total = 0
        for (p in px) {
            Color.colorToHSV(p, hsv)
            if (hsv[1] >= 0.35f && hsv[2] >= 0.45f) {
                val b = (hsv[0] / 10f).toInt().coerceIn(0, 35)
                hist[b]++; sumS[b] += hsv[1]; sumV[b] += hsv[2]; total++
            }
        }
        if (total < 20) return "ما لقيت لون واضح بالمنطقة. حدد مستطيل أصغر على الدوامة نفسها"
        var bestB = 0; var best = -1
        for (b in 0 until 36) {
            val c = hist[(b + 35) % 36] + hist[b] + hist[(b + 1) % 36]
            if (c > best) { best = c; bestB = b }
        }
        var sx = 0.0; var sy = 0.0; var cnt = 0; var ss = 0f; var sv = 0f
        for (dd in -1..1) {
            val b = (bestB + dd + 36) % 36
            val ang = Math.toRadians((b * 10 + 5).toDouble())
            sx += Math.cos(ang) * hist[b]; sy += Math.sin(ang) * hist[b]
            cnt += hist[b]; ss += sumS[b]; sv += sumV[b]
        }
        var hue = Math.toDegrees(Math.atan2(sy, sx)).toFloat()
        if (hue < 0) hue += 360f
        val meanS = ss / cnt; val meanV = sv / cnt
        val tol = 14f
        val minSat = maxOf(0.45f, meanS * 0.8f)
        val minVal = maxOf(0.55f, meanV * 0.8f)
        var match = 0
        for (p in px) {
            Color.colorToHSV(p, hsv)
            val d0 = Math.abs(hsv[0] - hue)
            val dh = minOf(d0, 360f - d0)
            if (dh <= tol && hsv[1] >= minSat && hsv[2] >= minVal) match++
        }
        val frac = match.toFloat() / (sw * sh) * (w.toFloat() * h / (f.width.toFloat() * f.height))
        Prefs.savePortal(this, slotNow, hue, tol, minSat, minVal, frac)
        return "تعلّمت دوامة $slotNow: لون ${hue.toInt()}° ، حجمها ${"%.1f".format(frac * 100)}% من الشاشة"
    }

    // ---------- التنبيه ----------
    private fun alert(label: String, color: Int) {
        try {
            val rt = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            rt.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            rt.play(); main.postDelayed({ rt.stop() }, 3500)
        } catch (_: Exception) {}
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 800), -1))
        } catch (_: Exception) {}
        flash(color)
        toast("لقيت: $label")
    }

    private fun flash(color: Int) {
        val v = View(this).apply { setBackgroundColor(color); alpha = 0f }
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        wm.addView(v, lp)
        ObjectAnimator.ofFloat(v, "alpha", 0f, 0.75f, 0f).apply {
            duration = 350; repeatCount = 5
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    try { wm.removeView(v) } catch (_: Exception) {}
                }
            })
            start()
        }
    }

    // ---------- الأزرار العائمة ----------
    fun showPanel() { main.post { if (panel == null) addPanel() } }

    fun hidePanel() {
        running = false; setWake(false)
        main.post {
            try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
            panel = null
        }
    }

    private fun tv(t: String) = TextView(this).apply {
        text = t; textSize = 22f; setTextColor(Color.WHITE); setPadding(22, 14, 22, 14)
    }

    private fun addPanel() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val drag = tv("✥"); val play = tv("▶"); val reg = tv("▢")
        val learn = tv("◎"); val slotBtn = tv("①"); val close = tv("✕")
        row.addView(drag); row.addView(play); row.addView(reg)
        row.addView(learn); row.addView(slotBtn); row.addView(close)
        playBtn = play

        val infoView = TextView(this).apply {
            textSize = 11f; setTextColor(Color.LTGRAY); setPadding(24, 0, 24, 14); text = "…"
            maxWidth = 900
        }
        info = infoView

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.argb(200, 20, 20, 20)); cornerRadius = 36f }
            addView(row); addView(infoView)
        }

        val lp = WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 200 }

        var ox = 0; var oy = 0; var tx = 0f; var ty = 0f
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ox = lp.x; oy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - tx).toInt(); lp.y = oy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(col, lp)
                }
            }
            true
        }
        play.setOnClickListener {
            running = !running
            play.text = if (running) "⏹" else "▶"
            setWake(running)
            if (running) { lastAlert = 0; setInfo("بدأ الفحص…") } else setInfo("متوقف")
        }
        reg.setOnClickListener { pickRegion(false) }
        learn.setOnClickListener { pickRegion(true) }
        slotBtn.setOnClickListener {
            slot = slot % 4 + 1
            slotBtn.text = "①②③④"[slot - 1].toString()
            setInfo("الخانة المختارة للتعليم: دوامة $slot")
        }
        close.setOnClickListener {
            hidePanel()
            toast("انخفت الأزرار. من التطبيق اضغط إظهار الأزرار")
        }
        wm.addView(col, lp); panel = col
    }

    private fun pickRegion(learn: Boolean) {
        val was = running; running = false
        val holder = arrayOfNulls<View>(1)
        val slotNow = slot
        val pv = RegionPicker(this) { r ->
            holder[0]?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            if (r.width() > 0f) {
                if (learn) {
                    scope?.launch { delay(500); learnFrom(r, slotNow) }
                } else {
                    Prefs.setRegion(this, r.left, r.top, r.right, r.bottom)
                    toast("انحفظت المنطقة")
                }
            }
            running = was
        }
        holder[0] = pv
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        wm.addView(pv, lp)
    }
}

package com.rarewatch.app

/**
 * hue: درجة اللون 0..360 (أحمر=0، أخضر=120، أزرق=240، بنفسجي≈280، وردي≈320). null = أبيض.
 * hueTol: التسامح بالدرجات. minSat/minVal: أقل تشبع وسطوع (0..1).
 * minPixels: أقل عدد بكسلات مطابقة حتى تعتبر مرشحة.
 * keyword: الكلمة المطلوب قراءتها بـ OCR للتأكيد (فارغ = لون فقط).
 */
data class Rule(
    val id: String,
    val label: String,
    val keyword: String,
    val hue: Float?,
    val hueTol: Float,
    val minSat: Float,
    val minVal: Float,
    val minPixels: Int,
    val flashColor: Int
)

object Rules {
    // عدّل القيم هنا حسب لقطاتك. أضف قاعدة جديدة بإضافة سطر.
    val all = listOf(
        Rule("hiba",  "هيبة (أحمر)",   "هيبة", 0f,   16f, 0.60f, 0.50f, 40, 0xFFFF0000.toInt()),
        Rule("satea", "ساطع (بنفسجي)", "ساطع", 300f, 30f, 0.30f, 0.60f, 40, 0xFFB000FF.toInt()),
        Rule("lamea", "لامعة (أبيض)",  "لامعة", null, 0f,  0.15f, 0.85f, 40, 0xFFFFFFFF.toInt())
    )
}

package com.rarewatch.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("rw", Context.MODE_PRIVATE)

    fun isEnabled(c: Context, id: String, def: Boolean = true) = p(c).getBoolean("on_$id", def)
    fun setEnabled(c: Context, id: String, v: Boolean) = p(c).edit().putBoolean("on_$id", v).apply()

    /** المنطقة كنسب من الشاشة: left, top, right, bottom */
    fun region(c: Context): FloatArray {
        val s = p(c)
        return floatArrayOf(
            s.getFloat("rl", 0.12f), s.getFloat("rt", 0.25f),
            s.getFloat("rr", 0.88f), s.getFloat("rb", 0.75f)
        )
    }
    fun setRegion(c: Context, l: Float, t: Float, r: Float, b: Float) =
        p(c).edit().putFloat("rl", l).putFloat("rt", t).putFloat("rr", r).putFloat("rb", b).apply()
}

package com.rarewatch.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("rw", Context.MODE_PRIVATE)

    fun isEnabled(c: Context, id: String, def: Boolean = true) = p(c).getBoolean("on_$id", def)
    fun setEnabled(c: Context, id: String, v: Boolean) = p(c).edit().putBoolean("on_$id", v).apply()

    /** المنطقة كنسب من الشاشة: left, top, right, bottom */
    fun region(c: Context): FloatArray {
        val s = p(c)
        return floatArrayOf(
            s.getFloat("rl", 0.12f), s.getFloat("rt", 0.25f),
            s.getFloat("rr", 0.88f), s.getFloat("rb", 0.75f)
        )
    }
    fun setRegion(c: Context, l: Float, t: Float, r: Float, b: Float) =
        p(c).edit().putFloat("rl", l).putFloat("rt", t).putFloat("rr", r).putFloat("rb", b).apply()

    fun ocrConfirm(c: Context) = p(c).getBoolean("ocr", true)
    fun setOcrConfirm(c: Context, v: Boolean) = p(c).edit().putBoolean("ocr", v).apply()

    fun portalName(c: Context, slot: Int) = p(c).getString("p${slot}_name", "") ?: ""
    fun setPortalName(c: Context, slot: Int, n: String) = p(c).edit().putString("p${slot}_name", n).apply()

    fun portal(c: Context, slot: Int): Portal? {
        val s = p(c)
        if (!s.contains("p${slot}_hue")) return null
        val name = portalName(c, slot).ifBlank { "دوامة $slot" }
        return Portal(slot, name, s.getFloat("p${slot}_hue", 0f), s.getFloat("p${slot}_tol", 22f),
            s.getFloat("p${slot}_sat", 0.4f), s.getFloat("p${slot}_val", 0.4f), s.getFloat("p${slot}_frac", 0.01f))
    }
    fun savePortal(c: Context, slot: Int, hue: Float, tol: Float, sat: Float, v: Float, frac: Float) =
        p(c).edit().putFloat("p${slot}_hue", hue).putFloat("p${slot}_tol", tol)
            .putFloat("p${slot}_sat", sat).putFloat("p${slot}_val", v).putFloat("p${slot}_frac", frac).apply()
    fun clearPortal(c: Context, slot: Int) =
        p(c).edit().remove("p${slot}_hue").remove("p${slot}_tol").remove("p${slot}_sat")
            .remove("p${slot}_val").remove("p${slot}_frac").apply()
}
